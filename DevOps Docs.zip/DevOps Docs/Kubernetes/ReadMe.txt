------------------------------https://dzone.com/articles/how-to-install-kubernetes-in-an-ubuntu-vm-------------------


# The command below installs Kubectl version 1.9.0
curl -LO https://storage.googleapis.com/kubernetes-release/release/v1.9.0/bin/linux/amd64/kubectl
# For stable version, use following command:
curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes- release/release/stable.txt)/bin/linux/amd64/kubectl


curl -Lo minikube https://storage.googleapis.com/minikube/releases/v0.24.1/minikube-linux-amd64 && chmod +x minikube && sudo mv minikube /usr/local/bin/
minikube version

deb http://download.virtualbox.org/virtualbox/debian xenial contrib

$ base=https://github.com/docker/machine/releases/download/v0.14.0 &&
  curl -L $base/docker-machine-$(uname -s)-$(uname -m) >/tmp/docker-machine &&
  sudo install /tmp/docker-machine /usr/local/bin/docker-machine
  
--------------------------------------------------------------------------------------------------------------

------------------https://www.techrepublic.com/article/how-to-quickly-install-kubernetes-on-ubuntu/--------------

  sudo apt-get update && apt-get install -y apt-transport-https
  
  sudo apt install docker.io
  
  sudo systemctl start docker
sudo systemctl enable docker

sudo curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add

apt-get update
apt-get install -y kubelet kubeadm kubectl kubernetes-cni

deb http://apt.kubernetes.io/ kubernetes-xenial main 

mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

sudo kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
sudo kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/k8s-manifests/kube-flannel-rbac.yml


