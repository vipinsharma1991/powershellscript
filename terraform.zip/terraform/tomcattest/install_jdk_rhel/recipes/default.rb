#
# Cookbook:: install_jdk_rhel
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

yum_package 'java' do
  action :install
end

#execute 'sudo echo export JAVA_HOME=/usr/java/java-1.8.0 >> ~/.bashrc'
execute 'export JAVA_HOME=/usr/lib/jvm/java-1.8.0'
execute  'export PATH=$PATH:$JAVA_HOME/bin'


=begin
yum_package 'java' do
  command 'export JAVA_HOME=/usr/lib/jvm/java-1.8.0'
end

yum_package 'java' do
  command 'export PATH=$PATH:$JAVA_HOME/bin'
end
=end
