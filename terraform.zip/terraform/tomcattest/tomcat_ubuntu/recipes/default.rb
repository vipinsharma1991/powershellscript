#
# Cookbook:: tomcat_ubuntu
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved
execute 'Update_Apt_get' do
  command 'sudo groupadd -f tomcat'
end
execute 'Update_Apt_get' do
  command 'sudo useradd -s /bin/false -g tomcat -d /opt/tomcat tomcat'
end
#install JDK-source

#update environment values
execute 'Update_Apt_get' do
  command 'sudo wget -P /srv/ https://www-us.apache.org/dist/tomcat/tomcat-8/v8.5.39/bin/apache-tomcat-8.5.39.tar.gz'
end

#update environment values
execute 'Update_Apt_get' do
  command 'sudo mkdir -p /opt/tomcat'
end

execute 'Update_Apt_get' do
  command 'sudo tar xzvf /srv/apache-tomcat-8.5.39.tar.gz -C /opt/tomcat --strip-components=1'
end


execute 'Update_Apt_get' do
  command 'sudo chgrp -R tomcat /opt/tomcat'
end

execute 'Update_Apt_get' do
  command 'sudo chmod -R g+r /opt/tomcat/conf'
end

execute 'Update_Apt_get' do
command 'sudo chmod g+x  /opt/tomcat/conf'
end


execute 'Update_Apt_get' do
command 'sudo chown -R tomcat /opt/tomcat/webapps/ /opt/tomcat/work/ /opt/tomcat/temp/ /opt/tomcat/logs/'
end

execute 'Update_Apt_get' do
command 'chmod 700 /opt/tomcat/bin/*.sh'
end

execute 'Update_Apt_get' do
command 'sudo ln -s /opt/tomcat/bin/startup.sh /usr/bin/tomcatup'
end

execute 'Update_Apt_get' do
command 'sudo ln -s /opt/tomcat/bin/shutdown.sh /usr/bin/tomcatdown'
end

execute "sudo sed -i -e 's/8080/8090/g' /opt/tomcat/conf/server.xml"


execute 'Create_Catalina_Folder' do
command 'sudo mkdir -p /opt/tomcat/conf/Catalina/localhost'
end


cookbook_file '/opt/tomcat/conf/Catalina/localhost/manager.xml' do
  source 'manager.xml'
  action :create
end

execute 'Delete_Tomcat_Users_file' do
command 'sudo rm -rf /opt/tomcat/conf/tomcat-users.xml'
end


cookbook_file '/opt/tomcat/conf/tomcat-users.xml' do
  source 'tomcat-users.xml'
  action :create
end




execute 'Update_Apt_get' do
command 'tomcatup'
end

execute 'Update_Apt_get' do
command 'sudo ufw allow 8081'
end

execute 'Update_Apt_get' do
command 'sudo ufw allow 8080'
end
