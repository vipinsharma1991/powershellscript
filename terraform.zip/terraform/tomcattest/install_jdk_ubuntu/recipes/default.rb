#
# Cookbook:: install_jdk_ubuntu
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
execute 'Update_Apt_get' do
  command 'sudo apt-get update'
end

#install JDK
execute 'Update_Apt_get' do
  command 'sudo apt-get -y install openjdk-8-jdk'
end

#install JDK-source
execute 'Update_Apt_get' do
  command 'sudo apt-get -y install openjdk-8-source'
end

execute 'sudo echo JAVA_HOME="/usr/lib/jvm/java-8-openjdk-amd64" >> /etc/environment'
cmd = `"source" "/etc/environment"`
#update environment values
=begin
execute 'Update_Apt_get' do
  command 'export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64'
end

#update environment values
execute 'Update_Apt_get' do
  command 'export PATH=$PATH:$JAVA_HOME/bin'
end

execute 'Update_Apt_get' do
  command 'source /etc/environment'
end
=end
execute 'Update_Apt_get' do
  command 'java -version'
end
