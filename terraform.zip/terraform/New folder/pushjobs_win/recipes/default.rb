#
# Cookbook:: pushjobs_win
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

unless node['push_jobs']['whitelist'].is_a? Hash
  raise "node['push_jobs']['whitelist'] should have a hash value!"
end

case node['platform_family']
when 'windows', 'debian', 'rhel', 'suse', 'amazon'
  include_recipe 'pushjobs_win::install'
else
  raise 'This cookbook currently supports only Windows, Debian-family Linux, RHEL-family Linux, and Suse.'
end
