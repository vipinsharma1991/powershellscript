
#
# Cookbook:: tomcat_rhel
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

execute 'sudo groupadd -f tomcat'


execute 'sudo useradd -s /bin/false -g tomcat -d /opt/tomcat tomcat'


execute 'sudo wget -P /srv/ https://www-us.apache.org/dist/tomcat/tomcat-8/v8.5.35/bin/apache-tomcat-8.5.35.tar.gz'

execute 'sudo mkdir -p /opt/tomcat'

execute 'sudo tar xzvf /srv/apache-tomcat-8.5.35.tar.gz -C /opt/tomcat --strip-components=1'

execute 'sudo chgrp -R tomcat /opt/tomcat'

execute 'sudo chmod -R g+r /opt/tomcat/conf'

execute 'sudo chmod g+x  /opt/tomcat/conf'

execute 'sudo chown -R tomcat /opt/tomcat/webapps/ /opt/tomcat/work/ /opt/tomcat/temp/ /opt/tomcat/logs/'

execute 'chmod 700 /opt/tomcat/bin/*.sh'

execute 'sudo ln -s /opt/tomcat/bin/startup.sh /usr/bin/tomcatup'

execute 'sudo ln -s /opt/tomcat/apache-tomcat-8.5.35/bin/shutdown.sh /usr/bin/tomcatdown'

execute "sudo sed -i -e 's/8080/8090/g' /opt/tomcat/conf/server.xml"

execute 'tomcatup'


execute 'sudo firewall-cmd --zone=public --add-port=8090/tcp --permanent'

execute 'sudo firewall-cmd --reload'


#execute 'sudo mv apache-tomcat-7.0.92-src /usr/local/tomcat' 
