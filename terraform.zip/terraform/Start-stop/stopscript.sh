AZ_PASS=igate@1234567
az login -u vipin.sharma@ncs.com.sg -p $AZ_PASS
az vm deallocate -g Resourcegroup -n VM_Name;