AZ_PASS=igate@1234567
az login -u vipin.sharma@ncs.com.sg -p $AZ_PASS
az vm start -g Resourcegroup -n VM_Name; 