#!/bin/bash
terraform init;
terraform import azurerm_virtual_network.myterraformnetwork /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/INDC01-RG/providers/Microsoft.Network/virtualNetworks/INDC01;
terraform import azurerm_network_security_group.myterraformnsg /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/INDC01-RG/providers/Microsoft.Network/networkSecurityGroups/SDE2-nsg;
terraform apply -auto-approve > log.txt;