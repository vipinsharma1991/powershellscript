#!/bin/bash
terraform init;

terraform import azurerm_resource_group.rg /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/${ResourceGroup};
terraform import azurerm_virtual_network.myterraformnetwork /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/INDC01-RG/providers/Microsoft.Network/virtualNetworks/INDC01;
terraform import azurerm_subnet.myterraformsubnet /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/${ResourceGroup}/providers/Microsoft.Network/virtualNetworks/${Virtual_Network}/subnets/${Virtual_Network_subnet};
terraform import azurerm_storage_account.mystorageaccount /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/${ResourceGroup}/providers/Microsoft.Storage/storageAccounts/{StorageAccount};
terraform import azurerm_network_security_group.myterraformnsg /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/INDC01-RG/providers/Microsoft.Network/networkSecurityGroups/SDE2-nsg;


terraform apply -auto-approve > log.txt;





terraform import azurerm_virtual_network.myterraformnetwork /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/INDC01-RG/providers/Microsoft.Network/virtualNetworks/INDC01;
terraform import azurerm_subnet.myterraformsubnet /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/SDE_RG/providers/Microsoft.Network/virtualNetworks/INDC01/subnets/SDE_subnet;
terraform import azurerm_storage_account.mystorageaccount /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/SDE_RG/providers/Microsoft.Storage/storageAccounts/sdeaccount;
terraform import azurerm_network_security_group.myterraformnsg /subscriptions/e9762748-076b-42e5-b1a8-c4bcf30f1137/resourceGroups/INDC01-RG/providers/Microsoft.Network/networkSecurityGroups/SDE2-nsg;